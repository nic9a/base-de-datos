host = "localhost"
port = 5432
user = "postgres"
passwd="postgres"
database = "bases"

